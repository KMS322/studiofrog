const MainS1 = () => {
  return (
    <div className="main_s1">
      <img src="/images/main_s1.jpg" alt="" />
    </div>
  );
};

export default MainS1;
